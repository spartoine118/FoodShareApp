package com.example.fromthestart;

public interface ItemSelectListener {

    void onItemClick(ItemModel itemModel);

}
