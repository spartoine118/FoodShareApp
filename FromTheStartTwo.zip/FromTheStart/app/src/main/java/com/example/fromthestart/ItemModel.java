package com.example.fromthestart;

public class ItemModel {

    String heading;

    public ItemModel(String heading) {
        this.heading = heading;
    }

    public String getHeading() {
        return heading;
    }

    public void setHeading(String heading) {
        this.heading = heading;
    }
}
