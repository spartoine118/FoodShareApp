package com.example.fromthestart;

import android.view.View;

public interface ItemSelectListener {

    void onItemClick(ItemModel itemModel, View view);

}
